from django.apps import AppConfig


class LoginAndRegistrationConfig(AppConfig):
    name = 'login_and_registration'
