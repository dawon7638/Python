from django.apps import AppConfig


class SemiRestfulTvShowsConfig(AppConfig):
    name = 'semi_restful_tv_shows'
