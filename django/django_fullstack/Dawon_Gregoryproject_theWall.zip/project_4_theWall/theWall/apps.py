from django.apps import AppConfig


class ThewallConfig(AppConfig):
    name = 'theWall'
