from django.apps import AppConfig


class FavoritebooksConfig(AppConfig):
    name = 'favoriteBooks'
