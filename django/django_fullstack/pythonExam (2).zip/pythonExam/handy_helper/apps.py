from django.apps import AppConfig


class HandyHelperConfig(AppConfig):
    name = 'handy_helper'
