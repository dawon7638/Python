from django.apps import AppConfig


class GreatNumberGameConfig(AppConfig):
    name = 'great_number_game'
