from django.apps import AppConfig


class Project5Config(AppConfig):
    name = 'project5'
