from django.apps import AppConfig


class TimeZoneConfig(AppConfig):
    name = 'time_zone'
