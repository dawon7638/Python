from django.shortcuts import render, HttpResponse, redirect










def index(request):
    return render(request, "index.html")

def time(request):
    
    return render(request, "index.html")
