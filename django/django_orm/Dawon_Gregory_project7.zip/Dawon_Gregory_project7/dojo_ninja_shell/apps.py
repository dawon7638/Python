from django.apps import AppConfig


class DojoNinjaShellConfig(AppConfig):
    name = 'dojo_ninja_shell'
