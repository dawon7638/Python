from django.apps import AppConfig


class UtempConfig(AppConfig):
    name = 'utemp'
