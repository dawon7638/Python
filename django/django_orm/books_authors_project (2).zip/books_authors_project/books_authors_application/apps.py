from django.apps import AppConfig


class BooksAuthorsApplicationConfig(AppConfig):
    name = 'books_authors_application'
