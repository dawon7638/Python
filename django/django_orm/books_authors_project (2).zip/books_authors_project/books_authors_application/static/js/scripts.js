$('document').ready(function(){
    $('p').click(function(){
        $('p').after('hello')
    });
})