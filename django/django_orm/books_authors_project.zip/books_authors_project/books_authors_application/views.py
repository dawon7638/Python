from django.shortcuts import render, HttpResponse, redirect
from django.http import JsonResponse
from books_authors_application.models import *

def index(request):
    return render(request,'index.html')